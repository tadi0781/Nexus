# ai_utils.py
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch

# Load the pre-trained model and tokenizer
model_path = "./ai_model"
tokenizer = AutoTokenizer.from_pretrained(model_path)
model = AutoModelForCausalLM.from_pretrained(model_path)

def generate_ai_response(prompt):
    """Generate AI response from a text prompt"""
    try:
        inputs = tokenizer.encode(prompt, return_tensors="pt")
        outputs = model.generate(
            inputs,
            max_length=100,         # Length of AI response
            pad_token_id=tokenizer.eos_token_id,
            do_sample=True,         # Allow creative responses
            top_k=50,               # Limit to top 50 words
            temperature=0.7         # Control randomness
        )
        return tokenizer.decode(outputs[0], skip_special_tokens=True)
    except Exception as e:
        return f"AI Error: {str(e)}"
