# app.py
from flask import Flask, render_template, redirect, url_for, flash, request, abort, session
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func, exc  # <-- ADDED func, exc
from flask_login import (
    LoginManager,
    UserMixin,
    login_user,
    logout_user,
    login_required,
    current_user,
)
from flask_migrate import Migrate
from flask_wtf import FlaskForm
from wtforms import (
    StringField,
    PasswordField,
    SubmitField,
    SelectField,
    TextAreaField,
)  # Consider DateField, FloatField from wtforms.fields.html5 or wtforms-components for better UX
from wtforms.validators import (
    DataRequired,
    Email,
    EqualTo,
    ValidationError,
    Optional,
    Length,
)

# <-- ADDED Optional
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.urls import url_parse
from functools import wraps
from datetime import datetime, timedelta, timezone

# from io import BytesIO # <-- REMOVED Unused import
# import qrcode # <-- REMOVED Unused import

app = Flask(__name__)
# !!! SECURITY WARNING: Change this key and load from environment/config file in production !!!
app.config["SECRET_KEY"] = "your-secret-key-change-me"
app.config["SQLALCHEMY_DATABASE_URI"] = (
    "sqlite:///nexus.db"  # Consider PostgreSQL/MySQL for production
)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = (
    0  # Disable caching during development (remove/change for production)
)
app.config["TEMPLATES_AUTO_RELOAD"] = True  # Okay for development

# Initialize extensions
db = SQLAlchemy(app)
migrate = Migrate(app, db)
login_manager = LoginManager(app)
login_manager.login_view = "login"


@login_manager.user_loader
def load_user(user_id):
    # Use db.session.get for primary key lookups (more efficient)
    return db.session.get(User, int(user_id))


# Custom Jinja filters
@app.template_filter("datetimeformat")
def datetimeformat(value, format="%Y-%m-%d %H:%M"):
    # Ensure value is a datetime object before formatting
    if isinstance(value, datetime):
        return value.strftime(format)
    return ""


# Models
class Role(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(
        db.String(80), unique=True, nullable=False, index=True
    )  # Added index
    description = db.Column(db.String(255))
    timestamp = db.Column(db.DateTime, default=datetime.now(timezone.utc))


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=True, index=True)
    password_hash = db.Column(db.String(128), nullable=True)
    full_name = db.Column(db.String(120))
    grade = db.Column(db.String(10))
    section = db.Column(db.String(10))
    role_id = db.Column(db.Integer, db.ForeignKey('role.id'), index=True)
    is_active = db.Column(db.Boolean, default=False)
    role = db.relationship('Role', backref='users')
    timestamp = db.Column(db.DateTime, default=datetime.now(timezone.utc))
    is_leader = db.Column(db.Boolean, default=False, index=True)
    leader_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True, index=True)
    leader = db.relationship('User', remote_side=[id], backref='followers')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        # Ensure password_hash is not None before checking
        if self.password_hash is None:
            return False
        return check_password_hash(self.password_hash, password)


class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(
        db.Integer, db.ForeignKey("user.id"), nullable=False, index=True
    )  # Added index
    receiver_id = db.Column(
        db.Integer, db.ForeignKey("user.id"), nullable=False, index=True
    )  # Added index
    # Note: Storing roles here might be redundant if User roles don't change often.
    # Could retrieve roles via sender/receiver relationships if needed.
    sender_role = db.Column(db.String(50))
    receiver_role = db.Column(db.String(50))
    content = db.Column(db.Text, nullable=False)
    timestamp = db.Column(
        db.DateTime, default=lambda: datetime.now(timezone.utc), index=True
    )  # Added index
    # is_read = db.Column(db.Boolean, default=False, index=True) # Consider adding for true 'unread' tracking

    sender = db.relationship("User", foreign_keys=[sender_id], backref="sent_messages")
    receiver = db.relationship(
        "User", foreign_keys=[receiver_id], backref="received_messages"
    )


# Asset Models
class AssetCategory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(
        db.String(50), unique=True, nullable=False, index=True
    )  # Added index
    description = db.Column(db.String(200))


class Asset(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False, index=True)  # Added index
    serial_number = db.Column(db.String(50), unique=True, index=True)  # Added index
    category_id = db.Column(
        db.Integer, db.ForeignKey("asset_category.id"), index=True
    )  # Added index
    purchase_date = db.Column(db.Date)
    purchase_cost = db.Column(db.Float)  # Consider using db.Numeric for precision
    location = db.Column(db.String(100))
    status = db.Column(db.String(20), default="Available", index=True)  # Added index
    notes = db.Column(db.Text)
    timestamp = db.Column(
        db.DateTime, default=lambda: datetime.now(timezone.utc), index=True
    )  # Added index (acts as created_at)
    category = db.relationship("AssetCategory", backref="assets")
    assigned_to = db.Column(
        db.Integer, db.ForeignKey("user.id"), nullable=True, index=True
    )  # Allow null, Added index
    assigned_user = db.relationship(
        "User", foreign_keys=[assigned_to], backref="assigned_assets"
    )


class MaintenanceRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    asset_id = db.Column(
        db.Integer, db.ForeignKey("asset.id"), nullable=False, index=True
    )  # Added index
    requester_id = db.Column(
        db.Integer, db.ForeignKey("user.id"), index=True
    )  # Added index
    description = db.Column(db.Text, nullable=False)
    urgency = db.Column(db.String(20), default="Medium")  # Low/Medium/High
    status = db.Column(
        db.String(20), default="Open", index=True
    )  # Open/In Progress/Closed, Added index
    timestamp = db.Column(
        db.DateTime, default=lambda: datetime.now(timezone.utc), index=True
    )  # Added index (acts as created_at)
    asset = db.relationship("Asset", backref="maintenance_requests")
    requester = db.relationship("User", backref="maintenance_requests")


# Add this with your other models
class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(
        db.Integer, db.ForeignKey("user.id"), nullable=False, index=True
    )
    receiver_id = db.Column(
        db.Integer, db.ForeignKey("user.id"), nullable=False, index=True
    )
    content = db.Column(db.Text, nullable=False)
    timestamp = db.Column(
        db.DateTime, default=lambda: datetime.now(timezone.utc), index=True
    )
    is_read = db.Column(db.Boolean, default=False, index=True)

    sender = db.relationship(
        "User", foreign_keys=[sender_id], backref="sent_notifications"
    )
    receiver = db.relationship(
        "User", foreign_keys=[receiver_id], backref="received_notifications"
    )


# Forms
class LoginForm(FlaskForm):
    username = StringField("Username", validators=[DataRequired()])
    password = PasswordField("Password", validators=[DataRequired()])
    submit = SubmitField("Login")


class RegistrationForm(FlaskForm):
    username = StringField("Username", validators=[DataRequired()])
    email = StringField("Email", validators=[DataRequired(), Email()])
    password = PasswordField("Password", validators=[DataRequired()])
    password2 = PasswordField(
        "Repeat Password",
        validators=[
            DataRequired(),
            EqualTo("password", message="Passwords must match"),
        ],
    )
    role = SelectField("Role", coerce=int, validators=[DataRequired()])
    submit = SubmitField("Register")

    def validate_username(self, username):
        # Use case-insensitive query
        user = db.session.scalar(
            db.select(User).filter(
                func.lower(User.username) == func.lower(username.data)
            )
        )
        if user:
            raise ValidationError(
                "Username already exists. Please choose a different one."
            )

    def validate_email(self, email):
        # Use case-insensitive query
        user = db.session.scalar(
            db.select(User).filter(func.lower(User.email) == func.lower(email.data))
        )
        if user:
            raise ValidationError("Email address already registered.")


class AssetForm(FlaskForm):
    name = StringField("Asset Name", validators=[DataRequired()])
    serial_number = StringField(
        "Serial Number", validators=[DataRequired()]
    )  # Validation for uniqueness happens in the route or model later if needed on edit
    category = SelectField("Category", coerce=int, validators=[DataRequired()])
    purchase_date = StringField(
        "Purchase Date (YYYY-MM-DD)"
    )  # Consider using DateField
    purchase_cost = StringField(
        "Purchase Cost"
    )  # Consider using FloatField or DecimalField
    location = StringField("Location")
    status = SelectField(
        "Status",
        choices=[
            ("Available", "Available"),
            (
                "CheckedOut",
                "Checked Out",
            ),  # Note: No logic currently handles who checked it out
            ("Maintenance", "Under Maintenance"),
            ("Retired", "Retired"),
        ],
    )
    # Use Optional() validator which allows empty/non-selection
    assigned_to = SelectField(
        "Assigned To", coerce=int, choices=[], validators=[Optional()]
    )
    notes = TextAreaField("Notes")
    submit = SubmitField("Save Asset")

    # Note: Unique validation for serial_number on create is handled below.
    # Need separate logic for edit form if serial number can be changed.
    def validate_serial_number_on_create(self, field):
        # Check only if we are creating (no instance attached yet or ID is None)
        # This simple check works if the form isn't pre-populated with an instance
        if Asset.query.filter_by(serial_number=field.data).first():
            raise ValidationError("Serial number already exists")

    def __init__(self, *args, **kwargs):
        super(AssetForm, self).__init__(*args, **kwargs)
        # Populate choices dynamically
        # Add a placeholder/instruction for 'None' selection
        self.assigned_to.choices = [(0, "--- Unassigned ---")] + [
            (user.id, user.username)
            for user in User.query.order_by(User.username).all()
        ]
        self.category.choices = [
            (c.id, c.name) for c in AssetCategory.query.order_by("name").all()
        ]


class MaintenanceRequestForm(FlaskForm):
    description = TextAreaField("Issue Description", validators=[DataRequired()])
    urgency = SelectField(
        "Urgency",
        choices=[("Low", "Low"), ("Medium", "Medium"), ("High", "High")],
        default="Medium",
    )  # Set default here
    submit = SubmitField("Submit Request")


class AssignLeaderForm(FlaskForm):
    leader = SelectField("Select Leader", coerce=int, validators=[DataRequired()])
    submit = SubmitField("Assign Leader(s)")

    def __init__(self, *args, **kwargs):
        super(AssignLeaderForm, self).__init__(*args, **kwargs)
        # Populate leader choices dynamically
        self.leader.choices = [(0, "--- Select a Leader ---")] + [
            (s.id, s.username)
            for s in User.query.join(Role)
            .filter(Role.name == "student", User.is_leader == True)
            .order_by(User.username)
            .all()
        ]


# Add to forms section
class NotificationForm(FlaskForm):
    content = TextAreaField("Message", validators=[DataRequired(), Length(max=1000)])
    submit = SubmitField("Send Notification")


class StudentVerificationForm(FlaskForm):
    unique_code = StringField('Unique Code', validators=[DataRequired()])
    grade = SelectField('Grade', choices=[
        ('9', 'Grade 9'), ('10', 'Grade 10'),
        ('11', 'Grade 11'), ('12', 'Grade 12')
    ], validators=[DataRequired()])
    section = StringField('Section', validators=[DataRequired()])
    submit = SubmitField('Verify Identity')

class StudentRegistrationForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    password2 = PasswordField('Repeat Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Complete Registration')

# Role management decorator
def role_required(*required_roles):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                flash("Please log in to access this page.", "warning")
                return redirect(url_for("login", next=request.url))

            user_role = current_user.role.name.lower() if current_user.role else None
            # Check if user_role is in the list/tuple of allowed roles (lowercase)
            allowed = [role.lower() for role in required_roles]
            if user_role not in allowed:
                app.logger.warning(
                    f"User {current_user.username} (Role: {user_role}) attempted to access restricted route requiring roles: {required_roles}"
                )
                abort(403)  # Forbidden
            return f(*args, **kwargs)

        return decorated_function

    return decorator


# --- Authentication Routes ---
@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("home"))

    form = LoginForm()
    if form.validate_on_submit():
        # Find user by username (case-insensitive recommended for usernames)
        user = db.session.scalar(
            db.select(User).filter(
                func.lower(User.username) == func.lower(form.username.data)
            )
        )

        if user and user.check_password(form.password.data):
            if not user.is_active:
                session["pending_user_id"] = user.id
                return redirect(url_for("complete_registration"))

            login_user(user)
            app.logger.info(f"User {user.username} logged in successfully.")
            next_page = request.args.get("next")

            # Validate next_page URL
            if not next_page or url_parse(next_page).netloc != "":
                # Determine dashboard based on role
                if user.role:
                    role_route_name = user.role.name.lower()
                    try:
                        # Attempt to build URL for the role-specific dashboard
                        next_page = url_for(f"{role_route_name}_dashboard")
                    except Exception as e:  # Catch BuildError specifically if needed
                        app.logger.error(
                            f"Failed to find dashboard route for role '{role_route_name}': {e}"
                        )
                        flash(
                            "Login successful, but your role dashboard could not be found.",
                            "warning",
                        )
                        next_page = url_for(
                            "fallback_dashboard"
                        )  # Define a fallback route if needed
                else:
                    # Handle users without a role assigned (should ideally not happen after registration)
                    app.logger.warning(
                        f"User {user.username} logged in but has no role assigned."
                    )
                    flash(
                        "Login successful, but you have no role assigned. Please contact support.",
                        "warning",
                    )
                    next_page = url_for(
                        "logout"
                    )  # Log them out or redirect to a generic page

            return redirect(next_page)
        else:
            app.logger.warning(
                f"Failed login attempt for username: {form.username.data}"
            )
            flash("Invalid username or password.", "danger")

    return render_template("auth/login.html", title="Login", form=form)


@app.route("/logout")
def logout():
    if current_user.is_authenticated:
        app.logger.info(f"User {current_user.username} logged out.")
        logout_user()
        flash("You have been logged out.", "info")
    return redirect(url_for("login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("home"))

    form = RegistrationForm()
    # Populate role choices dynamically, excluding potentially sensitive roles if needed
    form.role.choices = [
        (role.id, role.description) for role in Role.query.order_by("description")
    ]

    if form.validate_on_submit():
        try:
            role = db.session.get(Role, form.role.data)
            if not role:
                flash("Invalid role selected.", "danger")
                # Re-render form without committing
                return render_template(
                    "auth/register.html", title="Register", form=form
                )

            user = User(username=form.username.data, email=form.email.data, role=role)
            user.set_password(form.password.data)
            db.session.add(user)
            db.session.commit()
            app.logger.info(
                f"New user registered: {user.username} with role {role.name}"
            )
            flash("Registration successful! Please log in.", "success")
            return redirect(url_for("login"))
        except exc.IntegrityError as e:  # Catch specific IntegrityError
            db.session.rollback()
            app.logger.error(f"Registration failed due to IntegrityError: {e}")
            # Determine if it was username or email - more specific feedback possible
            if "user.username" in str(e.orig):
                form.username.errors.append("Username already exists.")
            elif "user.email" in str(e.orig):
                form.email.errors.append("Email already registered.")
            else:
                flash(
                    "Registration failed due to a database conflict. Please try different inputs.",
                    "danger",
                )
        except Exception as e:
            db.session.rollback()
            app.logger.error(f"An unexpected error occurred during registration: {e}")
            flash(
                "An unexpected error occurred during registration. Please try again.",
                "danger",
            )

    return render_template("auth/register.html", title="Register", form=form)


# --- Home / Fallback Routes ---
@app.route("/")
def home():
    if current_user.is_authenticated:
        if current_user.role:
            role_route_name = current_user.role.name.lower()
            try:
                # Redirect to role-specific dashboard
                return redirect(url_for(f"{role_route_name}_dashboard"))
            except Exception as e:
                app.logger.error(
                    f"Failed to find dashboard URL for role '{role_route_name}': {e}"
                )
                flash("Your role dashboard could not be found. Logging out.", "warning")
                return redirect(url_for("logout"))
        else:
            # User authenticated but no role - log out
            app.logger.warning(
                f"Authenticated user {current_user.username} has no role. Logging out."
            )
            flash("You have no assigned role. Please contact support.", "warning")
            return redirect(url_for("logout"))
    # Not authenticated, redirect to login
    return redirect(url_for("login"))


@app.route("/dashboard")  # Generic fallback dashboard
@login_required
def fallback_dashboard():
    # A simple page for users whose specific dashboard might be missing
    return render_template("dashboard_fallback.html", title="Dashboard")


@app.route('/student/verify', methods=['GET', 'POST'])
def verify_student():
    form = StudentVerificationForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.unique_code.data).first()
        if user and user.grade == form.grade.data and user.section == form.section.data:
            session['pending_user_id'] = user.id
            return redirect(url_for('complete_registration'))
        else:
            flash('Verification failed. Please check your details.')
    return render_template('auth/student_verify.html', form=form)


@app.route('/student/register', methods=['GET', 'POST'])
def complete_registration():
    if 'pending_user_id' not in session:
        return redirect(url_for('verify_student'))

    form = StudentRegistrationForm()
    user = User.query.get(session['pending_user_id'])

    if form.validate_on_submit():
        user.email = form.email.data
        user.set_password(form.password.data)
        user.is_active = True
        db.session.commit()
        login_user(user)
        session.pop('pending_user_id', None)
        return redirect(url_for('student_dashboard'))

    return render_template('auth/student_register.html', form=form)

# --- Dashboard Routes ---


# NOTE on "Unread Count": This currently counts messages received in the last 7 days.
# For true unread tracking, add an 'is_read' boolean to the Message model and update logic.
def get_recent_unread_count(user_id):
    # Example using the 7-day logic:
    seven_days_ago = datetime.now(timezone.utc) - timedelta(days=7)
    return db.session.scalar(
        db.select(func.count(Message.id)).filter(
            Message.receiver_id == user_id,
            Message.timestamp > seven_days_ago,
            # Add 'Message.is_read == False' if implementing true tracking
        )
    )


def get_unread_notifications_count(user_id):
    """Get unread notification count for dashboard"""
    return db.session.scalar(
        db.select(func.count(Notification.id)).filter_by(
            receiver_id=user_id, is_read=False
        )
    )


@app.route("/student/dashboard")
@login_required
@role_required("student")
def student_dashboard():
    if not current_user.is_active:
        flash("Please complete registration.", "warning")
        return redirect(url_for("complete_registration"))
    # Rest of dashboard logic
    recent_messages = db.session.scalars(
        db.select(Message)
        .filter_by(receiver_id=current_user.id)
        .order_by(Message.timestamp.desc())
        .limit(5)
    ).all()
    # Count HR CEOs
    hr_ceo_count = db.session.scalar(
        db.select(func.count(User.id)).join(Role).filter(Role.name == "hr_ceo")
    )
    # Count *other* students (more explicit than count - 1)
    other_student_count = db.session.scalar(
        db.select(func.count(User.id))
        .join(Role)
        .filter(
            Role.name == "student", User.id != current_user.id  # <-- CORRECTED Logic
        )
    )
    unread_count = get_recent_unread_count(current_user.id)

    return render_template(
        "student/dashboard.html",
        recent_messages=recent_messages,
        hr_ceo_count=hr_ceo_count,
        student_count=other_student_count,
        unread_count=unread_count,
        title="Student Dashboard",
    )


@app.route("/hr_ceo/dashboard")
@login_required
@role_required("hr_ceo")
def hr_ceo_dashboard():
    recent_messages = db.session.scalars(
        db.select(Message)
        .filter_by(receiver_id=current_user.id)
        .order_by(Message.timestamp.desc())
        .limit(5)
    ).all()

    student_count = db.session.scalar(
        db.select(func.count(User.id)).join(Role).filter(Role.name == "student")
    )
    leader_count = db.session.scalar(
        db.select(func.count(User.id)).filter_by(is_leader=True)
    )
    unread_count = get_recent_unread_count(current_user.id)

    # ✅ Add this line to get notification count
    unread_notifications = get_unread_notifications_count(current_user.id)

    return render_template(
        "hr_ceo/dashboard.html",
        recent_messages=recent_messages,
        student_count=student_count,
        leader_count=leader_count,
        unread_count=unread_count,
        # ✅ Pass notification count to template
        unread_notifications=unread_notifications,
        title="HR CEO Dashboard",
    )


# ... (Similar updates for ceo_dashboard, school_exec_dashboard adding titles and using get_recent_unread_count) ...


@app.route("/ceo/dashboard")
@login_required
@role_required("ceo")
def ceo_dashboard():
    recent_messages = db.session.scalars(
        db.select(Message)
        .filter_by(receiver_id=current_user.id)
        .order_by(Message.timestamp.desc())
        .limit(5)
    ).all()
    student_count = db.session.scalar(
        db.select(func.count(User.id)).join(Role).filter(Role.name == "student")
    )
    hr_ceo_count = db.session.scalar(
        db.select(func.count(User.id)).join(Role).filter(Role.name == "hr_ceo")
    )
    unread_count = get_recent_unread_count(current_user.id)
    return render_template(
        "ceo/dashboard.html",
        recent_messages=recent_messages,
        student_count=student_count,
        hr_ceo_count=hr_ceo_count,
        unread_count=unread_count,
        title="CEO Dashboard",
    )


@app.route("/school_exec/dashboard")
@login_required
@role_required("school_exec")
def school_exec_dashboard():
    recent_messages = db.session.scalars(
        db.select(Message)
        .filter_by(receiver_id=current_user.id)
        .order_by(Message.timestamp.desc())
        .limit(5)
    ).all()
    student_count = db.session.scalar(
        db.select(func.count(User.id)).join(Role).filter(Role.name == "student")
    )
    unread_count = get_recent_unread_count(current_user.id)
    return render_template(
        "school_exec/dashboard.html",
        recent_messages=recent_messages,
        student_count=student_count,
        unread_count=unread_count,
        title="School Exec Dashboard",
    )


@app.route("/maintenance/dashboard")
@login_required
@role_required("maintenance")
def maintenance_dashboard():
    pending_count = db.session.scalar(
        db.select(func.count(MaintenanceRequest.id)).filter_by(status="Open")
    )
    # Optionally add more stats: In Progress, Recently Closed etc.
    return render_template(
        "maintenance/dashboard.html",
        pending_count=pending_count,
        title="Maintenance Dashboard",
    )


# ... [All code before chat routes remains unchanged] ...


# --- Simple Dashboards (Add titles) ---
@app.route("/government/dashboard")
@login_required
@role_required("government")
def government_dashboard():
    return render_template("government/dashboard.html", title="Government Dashboard")


@app.route("/it_support/dashboard")
@login_required
@role_required("it_support")
def it_support_dashboard():
    return render_template("it_support/dashboard.html", title="IT Support Dashboard")


@app.route("/librarian/dashboard")
@login_required
@role_required("librarian")
def librarian_dashboard():
    return render_template("librarian/dashboard.html", title="Librarian Dashboard")


@app.route("/talent_club/dashboard")
@login_required
@role_required("talent_club")
def talent_club_dashboard():
    return render_template("talent_club/dashboard.html", title="Talent Club Dashboard")


@app.route("/teacher/dashboard")
@login_required
@role_required("teacher")
def teacher_dashboard():
    return render_template("teacher/dashboard.html", title="Teacher Dashboard")


@app.route("/system_admin/dashboard")
@login_required
@role_required("system_admin")
def system_admin_dashboard():
    return render_template(
        "system_admin/dashboard.html", title="System Admin Dashboard"
    )


# --- Updated Chat System ---
def get_chat_messages(user1_id, user2_id):
    return db.session.scalars(
        db.select(Message)
        .filter(
            ((Message.sender_id == user1_id) & (Message.receiver_id == user2_id))
            | ((Message.sender_id == user2_id) & (Message.receiver_id == user1_id))
        )
        .order_by(Message.timestamp.asc())
    ).all()


@app.route("/chat/<role>/<int:user_id>", methods=["GET", "POST"])
@login_required
def universal_chat(role, user_id):
    valid_roles = {
        "student": ["student"],
        "teacher": ["teacher", "hr_ceo"],
        "hr_ceo": ["teacher", "maintenance", "school_exec", "property_manager"],
        "property_manager": ["librarian", "it_support"],
        "maintenance": ["school_exec", "property_manager", "hr_ceo"],
        "school_exec": [
            "hr_ceo",
            "ceo",
            "property_manager",
            "maintenance",
            "government",
        ],
        "government": ["school_exec"],
        "ceo": ["school_exec"],
    }

    if role.lower() not in valid_roles:
        abort(403)

    target_user = db.session.get(User, user_id)
    if (
        not target_user
        or target_user.role.name.lower() not in valid_roles[role.lower()]
    ):
        abort(404 if target_user else 403)

    if request.method == "POST":
        content = request.form.get("message")
        if content:
            msg = Message(
                sender_id=current_user.id,
                receiver_id=target_user.id,
                sender_role=current_user.role.name,
                receiver_role=target_user.role.name,
                content=content,
            )
            db.session.add(msg)
            db.session.commit()
            return redirect(
                url_for("universal_chat", role=role, user_id=target_user.id)
            )
        else:
            flash("Cannot send an empty message.", "warning")

    messages = get_chat_messages(current_user.id, target_user.id)
    return render_template(
        f"chat/{role}.html",
        target_user=target_user,
        messages=messages,
        title=f"Chat with {target_user.username}",
        chat_route="universal_chat",
        role=role,
    )


@app.route("/contacts/<role>")
@login_required
def role_contacts(role):
    role_contacts_map = {
        "student": {
            "allowed_roles": ["student"],
            "template": "chat/student_contacts.html",
        },
        "teacher": {
            "allowed_roles": ["teacher", "hr_ceo"],
            "template": "chat/teacher_contacts.html",
        },
        "hr_ceo": {
            "allowed_roles": [
                "teacher",
                "maintenance",
                "school_exec",
                "property_manager",
            ],
            "template": "chat/hr_ceo_contacts.html",
        },
        "property_manager": {
            "allowed_roles": ["librarian", "it_support"],
            "template": "chat/property_manager_contacts.html",
        },
        "maintenance": {
            "allowed_roles": ["school_exec", "property_manager", "hr_ceo"],
            "template": "chat/maintenance_contacts.html",
        },
        "school_exec": {
            "allowed_roles": [
                "hr_ceo",
                "ceo",
                "property_manager",
                "maintenance",
                "government",
            ],
            "template": "chat/school_exec_contacts.html",
        },
        "government": {
            "allowed_roles": ["school_exec"],
            "template": "chat/government_contacts.html",
        },
        "ceo": {"allowed_roles": ["school_exec"], "template": "chat/ceo_contacts.html"},
    }

    if role.lower() not in role_contacts_map:
        abort(403)

    config = role_contacts_map[role.lower()]
    contacts = db.session.scalars(
        db.select(User)
        .join(Role)
        .filter(Role.name.in_(config["allowed_roles"]), User.id != current_user.id)
        .order_by(Role.name, User.username)
    ).all()

    return render_template(
        config["template"],
        contacts=contacts,
        title=f"{role.capitalize()} Contacts",
        chat_route="universal_chat",
        role=role,
    )


@app.route("/librarian/chat/<int:user_id>", methods=["GET", "POST"])
@login_required
@role_required("librarian")
def librarian_chat(user_id):
    target_user = db.session.get(User, user_id)
    if not target_user or target_user.role.name.lower() != "property_manager":
        abort(404 if target_user else 403)

    if request.method == "POST":
        content = request.form.get("message")
        if content:
            msg = Message(
                sender_id=current_user.id,
                receiver_id=target_user.id,
                sender_role=current_user.role.name,
                receiver_role=target_user.role.name,
                content=content,
            )
            db.session.add(msg)
            db.session.commit()
            return redirect(url_for("librarian_chat", user_id=target_user.id))

    messages = get_chat_messages(current_user.id, target_user.id)
    return render_template(
        "chat/librarian.html",
        target_user=target_user,
        messages=messages,
        title=f"Chat with {target_user.username}",
    )


@app.route("/it_support/chat/<int:user_id>", methods=["GET", "POST"])
@login_required
@role_required("it_support")
def it_support_chat(user_id):
    target_user = db.session.get(User, user_id)
    if not target_user or target_user.role.name.lower() != "property_manager":
        abort(404 if target_user else 403)

    if request.method == "POST":
        content = request.form.get("message")
        if content:
            msg = Message(
                sender_id=current_user.id,
                receiver_id=target_user.id,
                sender_role=current_user.role.name,
                receiver_role=target_user.role.name,
                content=content,
            )
            db.session.add(msg)
            db.session.commit()
            return redirect(url_for("it_support_chat", user_id=target_user.id))

    messages = get_chat_messages(current_user.id, target_user.id)
    return render_template(
        "chat/it_support.html",
        target_user=target_user,
        messages=messages,
        title=f"Chat with {target_user.username}",
    )


# --- HR CEO Leader Management Routes ---
@app.route("/hr_ceo/manage_leaders", methods=["GET", "POST"])
@login_required
@role_required("hr_ceo")
def manage_student_leaders():
    form = AssignLeaderForm()
    students = db.session.scalars(
        db.select(User)
        .join(Role)
        .filter(Role.name == "student")
        .order_by(User.username)
    ).all()
    current_leaders = [s for s in students if s.is_leader]

    if form.validate_on_submit():
        leader_id = form.leader.data
        leader = db.session.get(User, leader_id)
        if not leader or not leader.is_leader or leader.role.name != "student":
            flash("Invalid leader selected.", "danger")
            abort(400)

        selected_ids = [
            int(sid) for sid in request.form.getlist("students") if sid.isdigit()
        ]
        if not selected_ids:
            flash("No students selected to assign.", "warning")
        else:
            students_to_update = db.session.scalars(
                db.select(User).filter(User.id.in_(selected_ids))
            ).all()
            assigned_count = 0
            for student in students_to_update:
                if student.role.name == "student" and student.id != leader.id:
                    student.leader = leader
                    assigned_count += 1
            try:
                db.session.commit()
                flash(
                    f"{assigned_count} student(s) assigned to leader {leader.username}.",
                    "success",
                )
                return redirect(url_for("manage_student_leaders"))
            except Exception as e:
                db.session.rollback()
                app.logger.error(f"Error assigning leader: {e}")
                flash("An error occurred while assigning the leader.", "danger")

    return render_template(
        "hr_ceo/student_leaders.html",
        students=students,
        form=form,
        current_leaders=current_leaders,
        title="Manage Student Leaders",
    )


# ... [All remaining code after HR CEO routes remains unchanged] ...


@app.route(
    "/hr_ceo/toggle_leader/<int:student_id>", methods=["POST"]
)  # Ensure this is POST only
@login_required
@role_required("hr_ceo")
def toggle_student_leader(student_id):
    student = db.session.get(User, student_id)

    if not student or student.role.name != "student":
        flash("Student not found or invalid user type.", "danger")
        abort(404 if not student else 403)

    try:
        action = ""
        if student.is_leader:
            # Demoting: Remove followers first
            action = "demoted"
            # Update followers directly to avoid loading them all
            update_stmt = (
                db.update(User)
                .where(User.leader_id == student.id)
                .values(leader_id=None)
            )
            db.session.execute(update_stmt)
            student.is_leader = False
            app.logger.info(
                f"HR {current_user.username} demoted student {student.username} (ID: {student.id})."
            )
        else:
            # Promoting
            action = "promoted"
            student.is_leader = True
            # Ensure the promoted student doesn't follow anyone (or themselves)
            student.leader_id = None
            app.logger.info(
                f"HR {current_user.username} promoted student {student.username} (ID: {student.id})."
            )

        db.session.commit()
        flash(f"Successfully {action} {student.username}.", "success")

    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Error toggling leader status for student {student_id}: {e}")
        flash("Error updating leader status. Please try again.", "danger")

    # Redirect back to a relevant page, e.g., the student list or leader management page
    # Redirecting to manage_student_leaders might be more consistent
    return redirect(request.referrer or url_for("manage_student_leaders"))


# --- Asset Management Routes ---
@app.route("/property_manager/dashboard")
@login_required
@role_required("property_manager")
def property_manager_dashboard():
    # Use SQLAlchemy 2.0 style selects for aggregates
    total_assets = db.session.scalar(db.select(func.count(Asset.id)))
    available_assets = db.session.scalar(
        db.select(func.count(Asset.id)).filter_by(status="Available")
    )
    maintenance_assets = db.session.scalar(
        db.select(func.count(Asset.id)).filter_by(status="Maintenance")
    )

    # Get counts per category
    category_counts_stmt = (
        db.select(AssetCategory.name, func.count(Asset.id))
        .join(Asset.category)  # Use the relationship for join
        .group_by(AssetCategory.name)
    )
    category_counts = db.session.execute(category_counts_stmt).all()

    asset_stats = {
        "total": total_assets or 0,
        "available": available_assets or 0,
        "maintenance": maintenance_assets or 0,
        "categories": category_counts,  # List of (name, count) tuples
    }

    # Get recent assets using timestamp
    recent_assets = db.session.scalars(
        db.select(Asset)
        .order_by(Asset.timestamp.desc())
        .limit(5)  # <-- CORRECTED Field name
    ).all()

    return render_template(
        "property_manager/dashboard.html",
        asset_stats=asset_stats,
        recent_assets=recent_assets,
        title="Property Manager Dashboard",
    )


@app.route("/property_manager/assets")
@login_required
@role_required("property_manager")
def asset_list():
    page = request.args.get("page", 1, type=int)
    # Use select() for pagination with SQLAlchemy 2.0 style
    assets_paginated = db.paginate(
        db.select(Asset).order_by(Asset.name),  # Include order_by inside select
        page=page,
        per_page=10,
        error_out=False,  # error_out=False prevents 404 on invalid page
    )
    return render_template(
        "asset_management/asset_list.html",
        assets=assets_paginated,  # Pass the pagination object
        title="Asset List",
    )


@app.route("/property_manager/asset/create", methods=["GET", "POST"])
@login_required
@role_required("property_manager")
def create_asset():
    # Check if categories exist first
    if not db.session.query(AssetCategory.id).first():
        flash(
            "Cannot create assets: No asset categories found. Please add categories first (Admin task?).",
            "danger",
        )
        return redirect(url_for("property_manager_dashboard"))

    form = AssetForm()
    # Unique serial check specific to creation
    original_validate_serial = form.validate_serial_number_on_create
    del (
        form.validate_serial_number_on_create
    )  # Temporarily remove generic validator if exists

    if form.validate_on_submit():
        # Check serial number uniqueness specifically for creation
        if Asset.query.filter_by(serial_number=form.serial_number.data).first():
            form.serial_number.errors.append("Serial number already exists.")
            # Re-render form with error
            return render_template(
                "asset_management/asset_form.html", form=form, title="Create Asset"
            )

        try:
            purchase_date_obj = None
            if form.purchase_date.data:
                try:
                    purchase_date_obj = datetime.strptime(
                        form.purchase_date.data, "%Y-%m-%d"
                    ).date()
                except ValueError:
                    form.purchase_date.errors.append(
                        "Invalid date format. Use YYYY-MM-DD"
                    )
                    raise ValueError(
                        "Invalid date format"
                    )  # Re-raise to be caught below

            purchase_cost_float = 0.0
            if form.purchase_cost.data:
                try:
                    purchase_cost_float = float(form.purchase_cost.data)
                except ValueError:
                    form.purchase_cost.errors.append(
                        "Invalid cost format. Enter a number."
                    )
                    raise ValueError("Invalid cost format")  # Re-raise

            # Handle 'Unassigned' selection (value 0 from form __init__)
            assigned_user_id = (
                form.assigned_to.data if form.assigned_to.data != 0 else None
            )

            new_asset = Asset(
                name=form.name.data,
                serial_number=form.serial_number.data,
                category_id=form.category.data,
                purchase_date=purchase_date_obj,
                purchase_cost=purchase_cost_float,
                location=form.location.data,
                status=form.status.data,
                notes=form.notes.data,
                assigned_to=assigned_user_id,
            )
            db.session.add(new_asset)
            db.session.commit()
            app.logger.info(
                f"Asset created: {new_asset.name} (ID: {new_asset.id}) by {current_user.username}"
            )
            flash("Asset created successfully!", "success")
            return redirect(url_for("asset_detail", asset_id=new_asset.id))

        except ValueError as ve:
            # Date or Cost format error handled above, just render template
            db.session.rollback()  # Ensure no partial commit
            flash(f"Please correct the errors: {ve}", "danger")
            # Form already has errors appended in the try block
        except Exception as e:
            db.session.rollback()
            app.logger.error(f"Error creating asset: {e}")
            flash("An unexpected error occurred while creating the asset.", "danger")

    # Restore validator if needed elsewhere, or just rely on the specific check above for create
    # form.validate_serial_number = original_validate_serial
    return render_template(
        "asset_management/asset_form.html", form=form, title="Create Asset"
    )


@app.route("/property_manager/asset/<int:asset_id>")
@login_required
@role_required("property_manager")
def asset_detail(asset_id):
    # Use get_or_404 for cleaner handling of not found assets
    asset = db.get_or_404(Asset, asset_id)
    # Consider eager loading related data if always needed:
    # asset = db.session.get(Asset, asset_id, options=[db.joinedload(Asset.category), db.joinedload(Asset.assigned_user)])
    return render_template(
        "asset_management/asset_detail.html", asset=asset, title=f"Asset: {asset.name}"
    )


@app.route("/property_manager/asset/<int:asset_id>/edit", methods=["GET", "POST"])
@login_required
@role_required("property_manager")
def edit_asset(asset_id):
    asset = db.get_or_404(Asset, asset_id)
    form = AssetForm(obj=asset)  # Pre-populate form with asset data

    if form.validate_on_submit():
        # Check serial number uniqueness ONLY if it changed
        original_serial = asset.serial_number
        new_serial = form.serial_number.data
        if (
            new_serial != original_serial
            and Asset.query.filter(
                Asset.id != asset.id, Asset.serial_number == new_serial
            ).first()
        ):
            form.serial_number.errors.append(
                "Serial number already exists for another asset."
            )
            # Render form with error
            return render_template(
                "asset_management/asset_form.html", form=form, title="Edit Asset"
            )

        try:
            # Populate object with form data (excluding potential CSRF token etc.)
            form.populate_obj(asset)

            # Manually handle date conversion again
            if form.purchase_date.data:
                try:
                    asset.purchase_date = datetime.strptime(
                        form.purchase_date.data, "%Y-%m-%d"
                    ).date()
                except ValueError:
                    form.purchase_date.errors.append(
                        "Invalid date format. Use YYYY-MM-DD"
                    )
                    raise ValueError("Invalid date format")
            else:
                asset.purchase_date = None  # Allow clearing the date

            # Manually handle cost conversion
            if form.purchase_cost.data:
                try:
                    asset.purchase_cost = float(form.purchase_cost.data)
                except ValueError:
                    form.purchase_cost.errors.append(
                        "Invalid cost format. Enter a number."
                    )
                    raise ValueError("Invalid cost format")
            else:
                asset.purchase_cost = None  # Allow clearing the cost

            # Handle 'Unassigned' selection (value 0)
            asset.assigned_to = (
                form.assigned_to.data if form.assigned_to.data != 0 else None
            )

            db.session.commit()
            app.logger.info(f"Asset {asset.id} updated by {current_user.username}")
            flash("Asset updated successfully!", "success")
            return redirect(url_for("asset_detail", asset_id=asset.id))

        except ValueError as ve:
            db.session.rollback()
            flash(f"Please correct the errors: {ve}", "danger")
            # Form already has errors appended
        except Exception as e:
            db.session.rollback()
            app.logger.error(f"Error updating asset {asset_id}: {e}")
            flash("An unexpected error occurred while updating the asset.", "danger")

    # Pre-populate assigned_to field correctly for GET request or failed POST
    # The obj=asset handles most fields, but SelectField needs explicit data setting
    form.assigned_to.data = (
        asset.assigned_to if asset.assigned_to else 0
    )  # Use 0 for '--- Unassigned ---'
    # Pre-format date for the string field if it exists
    if asset.purchase_date:
        form.purchase_date.data = asset.purchase_date.strftime("%Y-%m-%d")
    # Pre-format cost (handle None)
    form.purchase_cost.data = (
        str(asset.purchase_cost) if asset.purchase_cost is not None else ""
    )

    return render_template(
        "asset_management/asset_form.html",
        form=form,
        title="Edit Asset",
        asset_id=asset_id,
    )


@app.route(
    "/property_manager/asset/<int:asset_id>/delete", methods=["POST"]
)  # Use POST for deletion
@login_required
@role_required("property_manager")
def delete_asset(asset_id):
    asset = db.get_or_404(Asset, asset_id)
    try:
        asset_name = asset.name  # Get name before deleting
        # Check for dependencies (e.g., Maintenance Requests) before deleting?
        # if asset.maintenance_requests:
        #     flash(f'Cannot delete asset "{asset_name}" as it has associated maintenance requests.', 'danger')
        #     return redirect(url_for('asset_detail', asset_id=asset_id))

        db.session.delete(asset)
        db.session.commit()
        app.logger.info(
            f'Asset "{asset_name}" (ID: {asset_id}) deleted by {current_user.username}'
        )
        flash(f'Asset "{asset_name}" deleted successfully.', "success")
        return redirect(url_for("asset_list"))
    except Exception as e:
        db.session.rollback()
        app.logger.error(f"Error deleting asset {asset_id}: {e}")
        flash("An error occurred while deleting the asset.", "danger")
        return redirect(url_for("asset_detail", asset_id=asset_id))


# --- Maintenance Routes ---

# Clarification on Maintenance Report Flow:
# Option 1 (Current Implied): GET /report_issue shows list, links go to GET /report_issue/<id> which shows form, POSTs to /submit_issue/<id>
# Option 2 (Alternative): GET /asset/<id> has "Report Issue" button linking to GET /asset/<id>/report, which shows form and POSTs to same URL.
# Option 3 (Simpler?): GET /report_issue shows a dropdown to select asset *and* the form. POST goes to /submit_issue (no ID in URL, gets ID from form data).

# Let's adjust to a slightly clearer flow (Closer to Option 1/2 mix):
# - GET /asset/<id> shows asset details. Add a "Report Issue" button here.
# - Button links to GET /asset/<id>/report_issue
# - GET /asset/<id>/report_issue shows the form for *that* asset.
# - Form POSTs back to /asset/<id>/report_issue


@app.route("/asset/<int:asset_id>/report_issue", methods=["GET", "POST"])
@login_required  # Any logged-in user can report
def report_issue_for_asset(asset_id):
    asset = db.get_or_404(Asset, asset_id)
    form = MaintenanceRequestForm()

    if form.validate_on_submit():
        try:
            new_request = MaintenanceRequest(
                asset_id=asset.id,
                requester_id=current_user.id,
                description=form.description.data,
                urgency=form.urgency.data,
                status="Open",  # Explicitly set status
            )
            # Optionally change asset status
            # asset.status = 'Maintenance'
            db.session.add(new_request)
            db.session.commit()
            app.logger.info(
                f"Maintenance request submitted for asset {asset.id} by user {current_user.id}"
            )
            flash(
                f'Maintenance request submitted successfully for asset "{asset.name}".',
                "success",
            )
            # Redirect back to the asset detail page after reporting
            return redirect(url_for("asset_detail", asset_id=asset.id))
        except Exception as e:
            db.session.rollback()
            app.logger.error(
                f"Error submitting maintenance request for asset {asset_id}: {e}"
            )
            flash("An error occurred while submitting the request.", "danger")
            # Fall through to render the form again

    # GET request or failed POST validation
    return render_template(
        "asset_management/report_issue_form.html",  # Use a dedicated form template
        form=form,
        asset=asset,
        title=f"Report Issue for {asset.name}",
    )


# Route for Maintenance staff to view requests
@app.route("/maintenance/requests")
@login_required
@role_required("maintenance")
def maintenance_requests():
    page = request.args.get("page", 1, type=int)
    # Paginate maintenance requests, ordered by timestamp descending
    requests_paginated = db.paginate(
        db.select(MaintenanceRequest).order_by(
            MaintenanceRequest.timestamp.desc()
        ),  # <-- CORRECTED Field name
        page=page,
        per_page=10,
        error_out=False,
    )
    # Consider eager loading related asset/requester data:
    # options(db.joinedload(MaintenanceRequest.asset), db.joinedload(MaintenanceRequest.requester))

    return render_template(
        "maintenance/request_list.html",
        requests=requests_paginated,  # Pass pagination object
        header_subtitle=f"Logged in as {current_user.username}",
        title="Maintenance Requests",
    )


# TODO: Add routes for Maintenance staff to update request status (e.g., In Progress, Closed)
# Example: /maintenance/request/<int:request_id>/update_status


# --- Database Initialization / CLI ---


# NOTE: Running create_all() and seeding on app start is okay for development.
# For production, use Flask-Migrate ('flask db upgrade') and potentially a separate seed command.
def create_initial_data():
    """Creates roles and categories if they don't exist."""
    with app.app_context():
        db.create_all()  # Ensure tables exist

        roles_to_create = [
            ("student", "Student"),
            ("hr_ceo", "HR CEO"),
            ("school_exec", "School Executive"),
            ("ceo", "CEO"),
            ("government", "Government"),
            ("it_support", "IT Support"),
            ("librarian", "Librarian"),
            ("maintenance", "Maintenance"),
            ("property_manager", "Property Manager"),
            ("system_admin", "System Admin"),
            ("talent_club", "Talent Club"),
            ("teacher", "Teacher"),
        ]
        existing_roles = {
            role.name for role in db.session.scalars(db.select(Role.name))
        }
        for name, desc in roles_to_create:
            if name not in existing_roles:
                db.session.add(Role(name=name, description=desc))
                app.logger.info(f"Created role: {name}")

        categories_to_create = [
            ("IT Equipment", "Computers, laptops, tablets"),
            ("Furniture", "Desks, chairs, cabinets"),
            ("Lab Equipment", "Microscopes, chemistry sets"),
            ("Sports Equipment", "Balls, nets, gym gear"),
            ("AV Equipment", "Projectors, speakers, cameras"),
            ("Books", "Library books, textbooks"),  # Added examples
        ]
        existing_categories = {
            cat.name for cat in db.session.scalars(db.select(AssetCategory.name))
        }
        for name, desc in categories_to_create:
            if name not in existing_categories:
                db.session.add(AssetCategory(name=name, description=desc))
                app.logger.info(f"Created asset category: {name}")

        try:
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            app.logger.error(f"Error creating initial data: {e}")


@app.route("/notifications")
@login_required
def view_notifications():
    notifications = db.session.scalars(
        db.select(Notification)
        .filter_by(receiver_id=current_user.id)
        .order_by(Notification.timestamp.desc())
    ).all()

    # Mark unread as read
    unread = [n for n in notifications if not n.is_read]
    for n in unread:
        n.is_read = True
    if unread:
        db.session.commit()

    return render_template("notifications/view.html", notifications=notifications)


@app.route("/notifications/contacts/<role>")
@login_required
def notification_contacts(role):
    """List valid contacts for notification based on role"""
    user_role = current_user.role.name.lower()
    if role != user_role or user_role not in NOTIFICATION_PERMISSIONS:
        abort(403)

    allowed_roles = NOTIFICATION_PERMISSIONS[user_role]
    if not allowed_roles:
        abort(403)

    contacts = db.session.scalars(
        db.select(User)
        .join(Role)
        .filter(Role.name.in_(allowed_roles), User.id != current_user.id)
        .order_by(Role.name, User.username)
    ).all()

    return render_template(
        "notifications/contacts.html", contacts=contacts, title="Select Recipient"
    )


@app.route("/notifications/send/<int:user_id>", methods=["GET", "POST"])
@login_required
def send_notification(user_id):
    """Send notification to specific user"""
    receiver = db.session.get(User, user_id)
    if not receiver:
        abort(404)

    sender_role = current_user.role.name.lower()
    receiver_role = receiver.role.name.lower()

    if receiver_role not in NOTIFICATION_PERMISSIONS.get(sender_role, []):
        abort(403)

    form = NotificationForm()
    if form.validate_on_submit():
        try:
            notification = Notification(
                sender_id=current_user.id,
                receiver_id=receiver.id,
                content=form.content.data,
            )
            db.session.add(notification)
            db.session.commit()
            flash("Notification sent successfully!", "success")
            return redirect(url_for("view_notifications"))
        except Exception as e:
            db.session.rollback()
            app.logger.error(f"Notification error: {e}")
            flash("Failed to send notification", "danger")

    return render_template(
        "notifications/form.html",
        form=form,
        receiver=receiver,
        title="Send Notification",
    )


# Add at module level (below other config)
NOTIFICATION_PERMISSIONS = {
    "government": [
        "student",
        "hr_ceo",
        "school_exec",
        "ceo",
        "government",
        "maintenance",
        "property_manager",
        "librarian",
        "it_support",
        "system_admin",
        "talent_club",
        "teacher",
    ],
    "school_exec": [
        "student",
        "hr_ceo",
        "ceo",
        "maintenance",
        "property_manager",
        "librarian",
        "it_support",
        "system_admin",
        "talent_club",
        "teacher",
    ],
    "maintenance": [
        "student",
        "hr_ceo",
        "property_manager",
        "librarian",
        "it_support",
        "system_admin",
        "talent_club",
        "teacher",
    ],
    "hr_ceo": ["talent_club", "teacher", "student", "property_manager"],
    "property_manager": ["librarian", "it_support"],
    # Non-senders
    "teacher": [],
    "student": [],
    "talent_club": [],
    "librarian": [],
    "it_support": [],
    "system_admin": [],
}


# Example CLI command for seeding (requires Flask Click commands)
@app.cli.command("seed-db")
def seed_db_command():
    """Creates initial roles and categories."""
    create_initial_data()
    print("Database seeded with initial roles and categories.")


# Main execution
if __name__ == "__main__":
    # create_initial_data() # Call this manually via 'flask seed-db' or during initial setup
    # Use Flask's built-in server for development only
    # For production, use a proper WSGI server like Gunicorn or uWSGI
    app.run(debug=True, host="0.0.0.0", port=5000)  # Listen on all
