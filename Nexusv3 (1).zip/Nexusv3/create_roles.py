# create_roles.py
from app import create_app, db
from auth.models import Role

app = create_app()

def create_roles():
    with app.app_context():
        roles = [
            ('student', 'Student'),
            ('teacher', 'Teacher'),
            ('librarian', 'Librarian'),
            ('system_admin', 'System Administrator'),
            ('ceo', 'CEO'),
            ('hr_ceo', 'HR CEO'),
            ('it_support', 'IT Support'),
            ('maintenance', 'Maintenance'),
            ('property_manager', 'Property Manager'),
            ('school_exec', 'School Executive'),
            ('talent_club', 'Talent Club'),
            ('government', 'Government')
        ]
        
        for role_name, description in roles:
            if not Role.query.filter_by(name=role_name).first():
                role = Role(name=role_name, description=description)
                db.session.add(role)
        
        db.session.commit()
        print("Roles created successfully")

if __name__ == '__main__':
    create_roles()