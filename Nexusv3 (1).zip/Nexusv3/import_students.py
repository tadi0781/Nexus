import csv
from app import app, db, User, Role

def import_students_from_csv(filename, grade):
    with open(filename, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            unique_code = row['UNIQUE_CODE'].strip()
            name = row['STUDENT_NAME'].strip()
            section = row['SECTION'].strip()
            
            # Skip if already exists
            if User.query.filter_by(username=unique_code).first():
                continue
            
            student_role = Role.query.filter_by(name='student').first()
            user = User(
                username=unique_code,
                full_name=name,
                grade=grade,
                section=section,
                role=student_role,
                is_active=False
            )
            db.session.add(user)
    
    db.session.commit()
    print(f"✅ Imported students from {filename}")

with app.app_context():
    print("🔄 Importing students from CSV files...")
    import_students_from_csv('grade09_students.csv', '9')
    import_students_from_csv('grade10_students.csv', '10')
    import_students_from_csv('grade11_students.csv', '11')
    import_students_from_csv('grade12_students.csv', '12')
    print("🎉 All students imported successfully!")