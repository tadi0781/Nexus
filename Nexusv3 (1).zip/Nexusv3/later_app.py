# app.py
from flask import Flask, request, jsonify, render_template
from ai_utils import generate_ai_response

app = Flask(__name__)

@app.route("/api/chat", methods=["POST"])
def chat_api():
    data = request.get_json()
    user_message = data.get("message", "")
    
    # Generate AI response
    ai_reply = generate_ai_response(user_message)
    
    return jsonify({
        "status": "success",
        "user": user_message,
        "ai": ai_reply
    })

# Keep your existing routes below...
