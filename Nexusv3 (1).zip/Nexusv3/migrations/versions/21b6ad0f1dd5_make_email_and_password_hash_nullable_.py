"""Make email and password_hash nullable for CSV import

Revision ID: 21b6ad0f1dd5
Revises: 48d67cdfb85c
Create Date: 2025-05-05 16:02:04.171772

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '21b6ad0f1dd5'
down_revision = '48d67cdfb85c'
branch_labels = None
depends_on = None


def upgrade():
    with op.batch_alter_table('user') as batch_op:
        batch_op.drop_column('email')
        batch_op.add_column(sa.Column('email', sa.String(120), nullable=True))
        batch_op.drop_column('password_hash')
        batch_op.add_column(sa.Column('password_hash', sa.String(128), nullable=True))

def downgrade():
    with op.batch_alter_table('user') as batch_op:
        batch_op.drop_column('password_hash')
        batch_op.add_column(sa.Column('password_hash', sa.String(128), nullable=False))
        batch_op.drop_column('email')
        batch_op.add_column(sa.Column('email', sa.String(120), nullable=False))
