"""Merge notification and student fields migrations

Revision ID: 48d67cdfb85c
Revises: 1742008565cf, 76618e28f2c0
Create Date: 2025-05-05 15:43:42.079935

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '48d67cdfb85c'
down_revision = ('1742008565cf', '76618e28f2c0')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
