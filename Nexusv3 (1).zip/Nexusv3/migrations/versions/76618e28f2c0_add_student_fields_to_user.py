# flake8: noqa
# type: ignore
"""Add student fields to User

Revision ID: 76618e28f2c0
Revises: 77dd82d8edfc
Create Date: 2025-05-04 13:00:00.000000
"""

from alembic import op
import sqlalchemy as sa

# Ensure these are defined at the top
revision = '76618e28f2c0'
down_revision = '77dd82d8edfc'
branch_labels = None
depends_on = None

def upgrade():
    with op.batch_alter_table('user') as batch_op:
        batch_op.alter_column('email',
                              existing_type=sa.String(length=120),
                              nullable=True)
        batch_op.alter_column('password_hash',
                              existing_type=sa.String(length=128),
                              nullable=True)

def downgrade():
    with op.batch_alter_table('user') as batch_op:
        batch_op.alter_column('password_hash',
                              existing_type=sa.String(length=128),
                              nullable=False)
        batch_op.alter_column('email',
                              existing_type=sa.String(length=120),
                              nullable=False)