// static/js/theme.js
document.addEventListener('DOMContentLoaded', function() {
  // Create animated particles
  const container = document.querySelector('.background-animation');
  for(let i = 0; i < 15; i++) {
    const particle = document.createElement('div');
    particle.className = 'particle';
    particle.style.width = particle.style.height = `${Math.random() * 10 + 10}px`;
    particle.style.top = `${Math.random() * 100}%`;
    particle.style.left = `${Math.random() * 100}%`;
    particle.style.animationDuration = `${Math.random() * 20 + 20}s`;
    particle.style.opacity = `${Math.random() * 0.3 + 0.2}`;
    particle.style.backgroundColor = Math.random() > 0.5 ? 
      `rgba(0, 246, 255, ${Math.random() * 0.3 + 0.2})` : 
      `rgba(125, 61, 255, ${Math.random() * 0.3 + 0.2})`;
    container.appendChild(particle);
  }

  // Add ripple effect to buttons
  document.querySelectorAll('.btn-vibrant').forEach(btn => {
    btn.addEventListener('click', function(e) {
      const ripple = document.createElement('span');
      ripple.className = 'ripple';
      ripple.style.left = `${e.offsetX}px`;
      ripple.style.top = `${e.offsetY}px`;
      this.appendChild(ripple);
      
      setTimeout(() => ripple.remove(), 1000);
    });
  });
});
